﻿namespace lab5_CS
{
    partial class Calulator
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            button21 = new Button();
            button22 = new Button();
            button23 = new Button();
            button24 = new Button();
            textBox1 = new TextBox();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 97);
            button1.Name = "button1";
            button1.Size = new Size(65, 61);
            button1.TabIndex = 0;
            button1.Text = "%";
            button1.UseVisualStyleBackColor = true;
            button1.Click += Form1_Click;
            // 
            // button3
            // 
            button3.Location = new Point(225, 97);
            button3.Name = "button3";
            button3.Size = new Size(65, 61);
            button3.TabIndex = 2;
            button3.Text = "1/x";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(83, 97);
            button4.Name = "button4";
            button4.Size = new Size(65, 61);
            button4.TabIndex = 3;
            button4.Text = " √";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button5
            // 
            button5.Location = new Point(154, 97);
            button5.Name = "button5";
            button5.Size = new Size(65, 61);
            button5.TabIndex = 4;
            button5.Text = "x²";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button6
            // 
            button6.Location = new Point(154, 164);
            button6.Name = "button6";
            button6.Size = new Size(65, 63);
            button6.TabIndex = 5;
            button6.Text = "<-";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.Location = new Point(12, 164);
            button7.Name = "button7";
            button7.Size = new Size(136, 63);
            button7.TabIndex = 6;
            button7.Text = "C";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Location = new Point(12, 311);
            button8.Name = "button8";
            button8.Size = new Size(65, 77);
            button8.TabIndex = 7;
            button8.Text = "4";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button24_Click;
            // 
            // button9
            // 
            button9.Location = new Point(225, 233);
            button9.Name = "button9";
            button9.Size = new Size(65, 72);
            button9.TabIndex = 8;
            button9.Text = "x";
            button9.UseVisualStyleBackColor = true;
            button9.Click += Form1_Click;
            // 
            // button10
            // 
            button10.Location = new Point(225, 164);
            button10.Name = "button10";
            button10.Size = new Size(65, 63);
            button10.TabIndex = 9;
            button10.Text = "/";
            button10.UseVisualStyleBackColor = true;
            button10.Click += Form1_Click;
            // 
            // button11
            // 
            button11.Location = new Point(83, 233);
            button11.Name = "button11";
            button11.Size = new Size(65, 72);
            button11.TabIndex = 10;
            button11.Text = "8";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button24_Click;
            // 
            // button12
            // 
            button12.Location = new Point(12, 233);
            button12.Name = "button12";
            button12.Size = new Size(65, 72);
            button12.TabIndex = 11;
            button12.Text = "7";
            button12.UseVisualStyleBackColor = true;
            button12.Click += button24_Click;
            // 
            // button13
            // 
            button13.Location = new Point(225, 311);
            button13.Name = "button13";
            button13.Size = new Size(65, 56);
            button13.TabIndex = 12;
            button13.Text = "-";
            button13.UseVisualStyleBackColor = true;
            button13.Click += Form1_Click;
            // 
            // button14
            // 
            button14.Location = new Point(154, 311);
            button14.Name = "button14";
            button14.Size = new Size(65, 77);
            button14.TabIndex = 13;
            button14.Text = "6";
            button14.UseVisualStyleBackColor = true;
            button14.Click += button24_Click;
            // 
            // button15
            // 
            button15.Location = new Point(83, 311);
            button15.Name = "button15";
            button15.Size = new Size(65, 77);
            button15.TabIndex = 14;
            button15.Text = "5";
            button15.UseVisualStyleBackColor = true;
            button15.Click += button24_Click;
            // 
            // button16
            // 
            button16.Location = new Point(154, 233);
            button16.Name = "button16";
            button16.Size = new Size(65, 72);
            button16.TabIndex = 15;
            button16.Text = "9";
            button16.UseVisualStyleBackColor = true;
            button16.Click += button24_Click;
            // 
            // button17
            // 
            button17.Location = new Point(154, 394);
            button17.Name = "button17";
            button17.Size = new Size(65, 73);
            button17.TabIndex = 16;
            button17.Text = "3";
            button17.UseVisualStyleBackColor = true;
            button17.Click += button24_Click;
            // 
            // button18
            // 
            button18.Location = new Point(83, 394);
            button18.Name = "button18";
            button18.Size = new Size(65, 73);
            button18.TabIndex = 17;
            button18.Text = "2";
            button18.UseVisualStyleBackColor = true;
            button18.Click += button24_Click;
            // 
            // button19
            // 
            button19.Location = new Point(12, 394);
            button19.Name = "button19";
            button19.Size = new Size(65, 73);
            button19.TabIndex = 18;
            button19.Text = "1";
            button19.UseVisualStyleBackColor = true;
            button19.Click += button24_Click;
            // 
            // button20
            // 
            button20.Location = new Point(12, 473);
            button20.Name = "button20";
            button20.Size = new Size(65, 39);
            button20.TabIndex = 19;
            button20.Text = ".";
            button20.UseVisualStyleBackColor = true;
            button20.Click += button20_Click;
            // 
            // button21
            // 
            button21.Location = new Point(225, 373);
            button21.Name = "button21";
            button21.Size = new Size(65, 53);
            button21.TabIndex = 20;
            button21.Text = "+";
            button21.UseVisualStyleBackColor = true;
            button21.Click += Form1_Click;
            // 
            // button22
            // 
            button22.Location = new Point(225, 432);
            button22.Name = "button22";
            button22.Size = new Size(65, 80);
            button22.TabIndex = 21;
            button22.Text = "=";
            button22.UseVisualStyleBackColor = true;
            button22.Click += button22_Click;
            // 
            // button23
            // 
            button23.Location = new Point(154, 473);
            button23.Name = "button23";
            button23.Size = new Size(65, 39);
            button23.TabIndex = 22;
            button23.Text = "+/-";
            button23.UseVisualStyleBackColor = true;
            button23.Click += button23_Click;
            // 
            // button24
            // 
            button24.Location = new Point(83, 473);
            button24.Name = "button24";
            button24.Size = new Size(65, 39);
            button24.TabIndex = 23;
            button24.Text = "0";
            button24.UseVisualStyleBackColor = true;
            button24.Click += button24_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Segoe UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(12, 29);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(278, 35);
            textBox1.TabIndex = 24;
            textBox1.Text = "0";
            // 
            // Calulator
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.GradientInactiveCaption;
            ClientSize = new Size(392, 539);
            Controls.Add(textBox1);
            Controls.Add(button24);
            Controls.Add(button23);
            Controls.Add(button22);
            Controls.Add(button21);
            Controls.Add(button20);
            Controls.Add(button19);
            Controls.Add(button18);
            Controls.Add(button17);
            Controls.Add(button16);
            Controls.Add(button15);
            Controls.Add(button14);
            Controls.Add(button13);
            Controls.Add(button12);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button1);
            FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MaximizeBox = false;
            Name = "Calulator";
            Text = "Calculator";
            Load += Form1_Load;
            Click += Form1_Click;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private Button button21;
        private Button button22;
        private Button button23;
        private Button button24;
        private TextBox textBox1;
    }
}
using System.Net;

namespace lab5_CS
{
    public partial class Calulator : Form
    {
        public string D;
        public string N1;
        public bool n2;
        public Calulator()
        {
            n2 = false;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {

        }

        private void button24_Click(object sender, EventArgs e)
        {

            if (n2)
            {
                n2 = false;
                textBox1.Text = "0";
            }


            Button B = (Button)sender;

            if (textBox1.Text == "0")
                textBox1.Text = B.Text;
            else
                textBox1.Text = textBox1.Text + B.Text;
        }

        private void button7_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void Form1_Click(object sender, EventArgs e)
        {
            Button B = (Button)sender;
            D = B.Text;
            N1 = textBox1.Text;
            n2 = true;
        }

        private void button22_Click(object sender, EventArgs e)
        {
            double dn1, dn2, res;
            res = 0;

            dn1 = (Convert.ToDouble(N1));
            dn2 = (Convert.ToDouble(textBox1.Text));

            if (D == "+")
                res = dn1 + dn2;
            if (D == "-")
                res = dn1 - dn2;
            if (D == "x")
                res = dn1 * dn2;
            if (D == "/")
                res = dn1 / dn2;
            if (D == "%")
                res = dn1 * dn2 / 100;
            D = "=";
            n2 = true;
            textBox1.Text = res.ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            double dn, res;
            res = 0;
            dn = (Convert.ToDouble(textBox1.Text));
            res = Math.Sqrt(dn);
            textBox1.Text = res.ToString();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            double n, res;
            n = (Convert.ToDouble(textBox1.Text));
            res = n * n;
            textBox1.Text = res.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double n, res;
            n = (Convert.ToDouble(textBox1.Text));
            res = 1 / n;
            textBox1.Text = res.ToString();
        }

        private void button23_Click(object sender, EventArgs e)
        {
            double n, res;
            n = (Convert.ToDouble(textBox1.Text));
            res = n * (-1);
            textBox1.Text = res.ToString();
        }

        private void button20_Click(object sender, EventArgs e)
        {
            if (!textBox1.Text.Contains(","))
                textBox1.Text = textBox1.Text + ",";
        }

        private void button6_Click(object sender, EventArgs e)
        {
            textBox1.Text = textBox1.Text.Substring(0, textBox1.Text.Length - 1);
            if (textBox1.Text == "")
                textBox1.Text = "0";
        }
    }
}